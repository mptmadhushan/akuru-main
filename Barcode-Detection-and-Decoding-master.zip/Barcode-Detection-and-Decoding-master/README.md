# Barcode-Detection-and-Decoding
Barcode detection and decoding using openCV and Zbar.

# Methodology
<img src="/imgs/method.png" width="800px" height="450px"></br>
# Approach Result
<img src="/imgs/approach.png" width="900px" height="450px"></br></br>
# Results
<img src="/imgs/result1.png" width="800px" height="450px"></br></br>
<img src="/imgs/result2.png" width="800px" height="450px"></br></br>
